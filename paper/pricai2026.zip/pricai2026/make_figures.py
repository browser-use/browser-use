"""Generate PRICAI 2026 paper figures 2--5 from daily-task-eval artifacts.

Default inputs are read from ``../../tmp/daily_task_eval`` relative to this file.
Outputs are written to ``figures/`` next to ``main.tex`` as PDF and PNG.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt


TASK_ORDER = [
	'shopping_price_compare',
	'nearby_hospital_phone_lookup',
	'github_clean_issue_audit',
	'huggingface_model_constrained_selection',
]
TASK_LABELS = {
	'shopping_price_compare': 'Shopping',
	'nearby_hospital_phone_lookup': 'Hospital',
	'github_clean_issue_audit': 'GitHub',
	'huggingface_model_constrained_selection': 'Hugging Face',
	'overall': 'Overall',
}
CODE_TO_PAPER = {
	'C': 'A',
	'D': 'B',
	'A': 'A',
	'B': 'B',
}
PAPER_LABELS = {
	'A': 'A: baseline',
	'B': 'B: + navigator',
}
PAPER_ORDER = ['A', 'B']
COLORS = {
	'A': '#4E79A7',
	'B': '#F28E2B',
}


def _repo_root() -> Path:
	return Path(__file__).resolve().parents[2]


def _default_data_dir() -> Path:
	return _repo_root() / 'tmp' / 'daily_task_eval'


def _read_csv(path: Path) -> list[dict[str, str]]:
	with path.open(encoding='utf-8-sig', newline='') as f:
		return [dict(row) for row in csv.DictReader(f)]


def _read_json(path: Path) -> Any:
	return json.loads(path.read_text(encoding='utf-8'))


def _first_existing(paths: list[Path]) -> Path:
	for path in paths:
		if path.exists():
			return path
	raise FileNotFoundError('None of these files exists:\n' + '\n'.join(f'  - {p}' for p in paths))


def _parse_bool(raw: Any) -> bool | None:
	if isinstance(raw, bool):
		return raw
	if raw is None:
		return None
	text = str(raw).strip().lower()
	if text in {'true', '1', 'yes', 'success'}:
		return True
	if text in {'false', '0', 'no', 'failure'}:
		return False
	return None


def _parse_float(raw: Any) -> float | None:
	if raw is None or raw == '':
		return None
	try:
		value = float(raw)
	except (TypeError, ValueError):
		return None
	if math.isnan(value):
		return None
	return value


def _paper_condition(row: dict[str, Any]) -> str | None:
	raw = row.get('experiment_id') or row.get('stats_experiment_id') or row.get('analysis_experiment_id') or row.get('method')
	if raw is None:
		return None
	text = str(raw).strip().upper()
	if text.startswith('EXP-'):
		text = text.removeprefix('EXP-')
	return CODE_TO_PAPER.get(text)


def _task_sort_key(task_id: str) -> tuple[int, str]:
	try:
		return (TASK_ORDER.index(task_id), task_id)
	except ValueError:
		return (len(TASK_ORDER), task_id)


def _mean(values: list[float]) -> float | None:
	return statistics.fmean(values) if values else None


def _std(values: list[float]) -> float | None:
	return statistics.stdev(values) if len(values) >= 2 else 0.0 if values else None


def _setup_style() -> None:
	plt.rcParams.update(
		{
			'font.family': 'DejaVu Sans',
			'font.size': 8.0,
			'axes.titlesize': 9.0,
			'axes.labelsize': 8.0,
			'xtick.labelsize': 7.0,
			'ytick.labelsize': 7.0,
			'legend.fontsize': 7.5,
			'pdf.fonttype': 42,
			'ps.fonttype': 42,
			'axes.spines.top': False,
			'axes.spines.right': False,
			'axes.grid': True,
			'grid.alpha': 0.22,
			'grid.linewidth': 0.6,
		}
	)


def _save(fig: plt.Figure, output_dir: Path, stem: str) -> None:
	output_dir.mkdir(parents=True, exist_ok=True)
	fig.savefig(output_dir / f'{stem}.pdf', bbox_inches='tight')
	fig.savefig(output_dir / f'{stem}.png', dpi=300, bbox_inches='tight')
	plt.close(fig)


def _load_run_rows(data_dir: Path) -> list[dict[str, str]]:
	candidates = [
		data_dir / 'batch_20260624_runs.csv',
		data_dir / 'share_out' / 'batch_20260624_runs.csv',
		data_dir / 'share_out' / 'agent_runs_export.csv',
	]
	for path in candidates:
		if path.exists():
			return _read_csv(path)

	csv_dir = data_dir / 'csv_out'
	paths = sorted(csv_dir.glob('exp-*_runs.csv')) if csv_dir.exists() else []
	if paths:
		rows: list[dict[str, str]] = []
		for path in paths:
			rows.extend(_read_csv(path))
		return rows

	raise FileNotFoundError(
		'Could not find run-level CSV. Expected batch_20260624_runs.csv, '
		'share_out/agent_runs_export.csv, or csv_out/exp-*_runs.csv.'
	)


def _load_stats_rows(data_dir: Path) -> list[dict[str, str]]:
	candidates = [
		data_dir / 'share_out' / 'experiment_resource_report_stats.csv',
		data_dir / 'experiment_resource_report_stats.csv',
		data_dir / 'resource_summary.csv',
	]
	for path in candidates:
		if path.exists():
			return _read_csv(path)
	return _aggregate_stats_from_runs(_load_run_rows(data_dir))


def _aggregate_stats_from_runs(rows: list[dict[str, str]]) -> list[dict[str, str]]:
	buckets: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
	for row in rows:
		task_id = str(row.get('task_id') or '')
		cond = _paper_condition(row)
		if task_id in TASK_ORDER and cond in PAPER_ORDER:
			buckets[(task_id, cond)].append(row)

	out: list[dict[str, str]] = []
	for (task_id, cond), bucket in sorted(buckets.items(), key=lambda item: (_task_sort_key(item[0][0]), item[0][1])):
		duration = [_parse_float(r.get('duration_seconds')) for r in bucket]
		steps = [_parse_float(r.get('number_of_steps')) for r in bucket]
		total_tokens = [
			_parse_float(r.get('total_tokens'))
			or ((_parse_float(r.get('tokens_executor')) or 0.0) + (_parse_float(r.get('tokens_navigator')) or 0.0))
			for r in bucket
		]
		cost = [_parse_float(r.get('full_run_cost_cny')) or _parse_float(r.get('total_cost')) for r in bucket]
		token_efficiency = [_parse_float(r.get('token_efficiency_score')) for r in bucket]
		out.append(
			{
				'task_id': task_id,
				'stats_experiment_id': cond,
				'stats_is_pooled': 'false',
				'run_count': str(len(bucket)),
				'duration_seconds_mean': str(_mean([v for v in duration if v is not None]) or ''),
				'duration_seconds_std': str(_std([v for v in duration if v is not None]) or ''),
				'number_of_steps_mean': str(_mean([v for v in steps if v is not None]) or ''),
				'total_tokens_mean': str(_mean([v for v in total_tokens if v is not None]) or ''),
				'total_tokens_std': str(_std([v for v in total_tokens if v is not None]) or ''),
				'total_cost_mean': str(_mean([v for v in cost if v is not None]) or ''),
				'total_cost_std': str(_std([v for v in cost if v is not None]) or ''),
				'token_efficiency_score_mean': str(_mean([v for v in token_efficiency if v is not None]) or ''),
			}
		)
	return out


def _bar_offsets(index: int, width: float) -> float:
	return (index - (len(PAPER_ORDER) - 1) / 2) * width


def plot_fig2(data_dir: Path, output_dir: Path) -> None:
	rows = _load_run_rows(data_dir)
	counts: dict[tuple[str, str], list[bool]] = defaultdict(list)
	for row in rows:
		task_id = str(row.get('task_id') or '')
		cond = _paper_condition(row)
		strict = _parse_bool(row.get('strict_success'))
		if task_id in TASK_ORDER and cond in PAPER_ORDER and strict is not None:
			counts[(task_id, cond)].append(strict)

	tasks = [*TASK_ORDER, 'overall']
	fig, ax = plt.subplots(figsize=(6.6, 2.7))
	width = 0.34
	xs = list(range(len(tasks)))
	for i, cond in enumerate(PAPER_ORDER):
		rates: list[float] = []
		labels: list[str] = []
		for task_id in tasks:
			values = []
			if task_id == 'overall':
				for tid in TASK_ORDER:
					values.extend(counts.get((tid, cond), []))
			else:
				values = counts.get((task_id, cond), [])
			successes = sum(values)
			total = len(values)
			rates.append(successes / total if total else 0.0)
			labels.append(f'{successes}/{total}' if total else 'n/a')

		positions = [x + _bar_offsets(i, width) for x in xs]
		ax.bar(positions, rates, width=width, color=COLORS[cond], label=PAPER_LABELS[cond])
		for x, y, label in zip(positions, rates, labels, strict=False):
			ax.text(x, y + 0.025, label, ha='center', va='bottom', fontsize=6.8)

	ax.set_ylabel('Strict success rate')
	ax.set_ylim(0, 1.12)
	ax.set_xticks(xs)
	ax.set_xticklabels([TASK_LABELS[t] for t in tasks], rotation=18, ha='right')
	ax.legend(frameon=False, ncols=2, loc='upper left')
	fig.tight_layout()
	_save(fig, output_dir, 'fig2')


def _stat_value(row: dict[str, str], *names: str) -> float | None:
	for name in names:
		value = _parse_float(row.get(name))
		if value is not None:
			return value
	return None


def _stats_by_task_condition(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
	out: dict[tuple[str, str], dict[str, str]] = {}
	for row in rows:
		task_id = str(row.get('task_id') or '')
		cond = _paper_condition(row)
		is_pooled = str(row.get('stats_is_pooled') or '').strip().lower() in {'true', '1', 'yes'}
		if task_id in TASK_ORDER and cond in PAPER_ORDER and not is_pooled:
			out[(task_id, cond)] = row
	return out


def plot_fig3(data_dir: Path, output_dir: Path) -> None:
	stats = _stats_by_task_condition(_load_stats_rows(data_dir))
	fig, ax = plt.subplots(figsize=(6.2, 2.65))
	width = 0.34
	xs = list(range(len(TASK_ORDER)))

	for i, cond in enumerate(PAPER_ORDER):
		means = [_stat_value(stats.get((task_id, cond), {}), 'duration_seconds_mean', 'mean_duration_seconds') or 0.0 for task_id in TASK_ORDER]
		stds = [_stat_value(stats.get((task_id, cond), {}), 'duration_seconds_std', 'std_duration_seconds') or 0.0 for task_id in TASK_ORDER]
		positions = [x + _bar_offsets(i, width) for x in xs]
		ax.bar(
			positions,
			means,
			width=width,
			yerr=stds,
			capsize=2.5,
			color=COLORS[cond],
			label=PAPER_LABELS[cond],
			error_kw={'elinewidth': 0.8, 'capthick': 0.8},
		)

	ax.set_ylabel('Duration (s)')
	ax.set_xticks(xs)
	ax.set_xticklabels([TASK_LABELS[t] for t in TASK_ORDER], rotation=15, ha='right')
	ax.legend(frameon=False, ncols=2, loc='upper left')
	fig.tight_layout()
	_save(fig, output_dir, 'fig3')


def plot_fig4(data_dir: Path, output_dir: Path) -> None:
	stats = _stats_by_task_condition(_load_stats_rows(data_dir))
	fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8), sharex=True)
	width = 0.34
	xs = list(range(len(TASK_ORDER)))

	panels = [
		(axes[0], ('total_tokens_mean', 'actual_total_tokens_mean', 'mean_total_tokens'), ('total_tokens_std', 'actual_total_tokens_std'), 'Actual total tokens'),
		(axes[1], ('full_run_cost_cny_mean', 'full_run_cost_cny', 'total_cost_mean'), ('full_run_cost_cny_std', 'total_cost_std'), 'Estimated full cost'),
	]
	for ax, mean_names, std_names, ylabel in panels:
		for i, cond in enumerate(PAPER_ORDER):
			means = [_stat_value(stats.get((task_id, cond), {}), *mean_names) or 0.0 for task_id in TASK_ORDER]
			stds = [_stat_value(stats.get((task_id, cond), {}), *std_names) or 0.0 for task_id in TASK_ORDER]
			positions = [x + _bar_offsets(i, width) for x in xs]
			ax.bar(
				positions,
				means,
				width=width,
				yerr=stds,
				capsize=2.5,
				color=COLORS[cond],
				label=PAPER_LABELS[cond],
				error_kw={'elinewidth': 0.8, 'capthick': 0.8},
			)
		ax.set_ylabel(ylabel)
		ax.set_xticks(xs)
		ax.set_xticklabels([TASK_LABELS[t] for t in TASK_ORDER], rotation=18, ha='right')

	axes[0].legend(frameon=False, ncols=2, loc='upper left')
	fig.tight_layout()
	_save(fig, output_dir, 'fig4')


def _load_comparison_rows(data_dir: Path) -> list[dict[str, Any]]:
	path = _first_existing(
		[
			data_dir / 'comparison_report.json',
			data_dir / 'share_out' / 'comparison_report.json',
		]
	)
	data = _read_json(path)
	if isinstance(data, dict):
		for key in ('lcs_pairs', 'comparisons', 'comparison_records', 'outcome_table'):
			rows = data.get(key)
			if isinstance(rows, list):
				return [row for row in rows if isinstance(row, dict)]
		raise ValueError(f'Could not find a row list in comparison report object: {path}')
	if not isinstance(data, list):
		raise ValueError(f'Expected comparison report list/object, got {type(data).__name__}: {path}')
	return [row for row in data if isinstance(row, dict)]


def plot_fig5(data_dir: Path, output_dir: Path) -> None:
	rows = _load_comparison_rows(data_dir)
	values: dict[tuple[str, str], list[float]] = defaultdict(list)
	for row in rows:
		task_id = str(row.get('task_id') or '')
		cond = _paper_condition(row)
		lcs = _parse_float(row.get('canonical_lcs_score'))
		if lcs is None:
			lcs = _parse_float(row.get('canonical_lcs'))
		if task_id in TASK_ORDER and cond in PAPER_ORDER and lcs is not None:
			values[(task_id, cond)].append(lcs)

	fig, ax = plt.subplots(figsize=(6.4, 2.85))
	width = 0.30
	base_positions = list(range(len(TASK_ORDER)))
	for i, cond in enumerate(PAPER_ORDER):
		positions = [x + _bar_offsets(i, width) for x in base_positions]
		data = [values.get((task_id, cond), []) for task_id in TASK_ORDER]
		box = ax.boxplot(
			data,
			positions=positions,
			widths=width * 0.82,
			patch_artist=True,
			showfliers=False,
			medianprops={'color': '#222222', 'linewidth': 1.0},
			boxprops={'linewidth': 0.8},
			whiskerprops={'linewidth': 0.8},
			capprops={'linewidth': 0.8},
		)
		for patch in box['boxes']:
			patch.set_facecolor(COLORS[cond])
			patch.set_alpha(0.28)
			patch.set_edgecolor(COLORS[cond])

		for pos, points in zip(positions, data, strict=False):
			if not points:
				continue
			if len(points) == 1:
				jittered = [pos]
			else:
				step = min(0.08, width / max(2, len(points)))
				start = -step * (len(points) - 1) / 2
				jittered = [pos + start + step * j for j in range(len(points))]
			ax.scatter(jittered, points, s=15, color=COLORS[cond], alpha=0.85, linewidths=0)
			ax.text(pos, 1.03, f'n={len(points)}', ha='center', va='bottom', fontsize=6.4, color=COLORS[cond])

	ax.set_ylabel('Canonical LCS')
	ax.set_ylim(0, 1.12)
	ax.set_xticks(base_positions)
	ax.set_xticklabels([TASK_LABELS[t] for t in TASK_ORDER], rotation=15, ha='right')
	handles = [plt.Line2D([0], [0], color=COLORS[c], marker='s', linestyle='', markersize=6) for c in PAPER_ORDER]
	ax.legend(handles, [PAPER_LABELS[c] for c in PAPER_ORDER], frameon=False, ncols=2, loc='upper left')
	fig.tight_layout()
	_save(fig, output_dir, 'fig5')


def generate_all(data_dir: Path, output_dir: Path) -> None:
	_setup_style()
	plot_fig2(data_dir, output_dir)
	plot_fig3(data_dir, output_dir)
	plot_fig4(data_dir, output_dir)
	plot_fig5(data_dir, output_dir)


def main() -> int:
	parser = argparse.ArgumentParser(description='Generate PRICAI 2026 figures 2--5.')
	parser.add_argument('--data-dir', type=Path, default=_default_data_dir())
	parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent / 'figures')
	args = parser.parse_args()

	generate_all(args.data_dir, args.output_dir)
	print(f'Wrote fig2--fig5 PDF/PNG files to {args.output_dir.resolve()}')
	return 0


if __name__ == '__main__':
	raise SystemExit(main())
