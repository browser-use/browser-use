# PRICAI 2026 paper draft — navigator vs. no-navigator browser agent

This folder contains a LaTeX draft of a controlled study: does a lightweight LLM
"navigator" (planner) improve a CDP browser agent on realistic Chinese-locale
daily web tasks, with the executor LLM held fixed?

- Conditions compared: **A** (executor only, `--experiment C`) vs. **B** (DeepSeek navigator + executor, `--experiment D`).
  The paper uses the labels *Experiment A* and *Experiment B* for the two conditions.
  The underlying implementation refers to the same configurations as experiment presets
  **C** and **D** respectively; the mapping is paper‑A → code‑C, paper‑B → code‑D.
- Executor (both): Doubao `doubao-seed-2-0-pro-260215`, temp 0, no vision.
- Matrix: 4 tasks × 2 conditions × 6 reps = 48 runs (run 2026-06-24).

## Files

| File | Purpose |
|------|---------|
| `main.tex` | Full paper (Springer LNCS class). Core result/efficiency tables are filled with real numbers. |
| `references.bib` | Starter bibliography. Several fields marked `% TODO verify`. |
| `README.md` | This file. |
| `figures/` | (You create.) Drop `fig1.pdf`…`fig5.pdf` here. |

## Prerequisites: the LNCS class files

PRICAI proceedings are Springer LNAI/LNCS, so `main.tex` uses
`\documentclass[runningheads]{llncs}`. The class file is **not** redistributed
here. Download the official Springer LNCS authoring kit and place these next to
`main.tex`:

- `llncs.cls`
- `splncs04.bst`

Source: <https://www.springer.com/gp/computer-science/lncs/conference-proceedings-guidelines>
(Overleaf's "Springer LNCS" template bundles both.)

If you only want to preview content without the class files, `main.tex` contains
a commented `\documentclass{article}` fallback block near the top. Switch to it
temporarily; the camera-ready must use `llncs`.

## Build

The paper contains Chinese (CJK) strings, so **XeLaTeX (or LuaLaTeX) is the
recommended engine** — it handles UTF-8 CJK natively. All CJK is wrapped in a
`\cn{...}` macro and the engine is auto-detected via `iftex`.

```bash
xelatex main
bibtex  main
xelatex main
xelatex main
```

- Under XeLaTeX, `main.tex` sets `\setCJKmainfont{SimSun}` (ships with Windows).
  On Linux/Overleaf change it to an installed CJK font (e.g. `Noto Sans CJK SC`).
- A **pdfLaTeX fallback** is provided via `CJKutf8` (requires CJK package fonts,
  e.g. arphic/gbsn). If you have no CJK fonts at all, replace the `\cn{...}`
  contents with romanized text.

> The document compiles **even before you generate the figures**: `main.tex`
> defines a `\figplaceholder` helper that draws a labelled box whenever a
> `figures/figN.pdf` is missing. Replace each PDF to get the real figure, then
> remove the helper for the camera-ready if you wish.

## Data provenance

Every quantitative claim in the paper traces to a file under
`../../tmp/daily_task_eval/`:

- `batch_20260624_runs.csv` — per-run results (strict_success, adjudication, duration, steps).
- `share_out/experiment_resource_report_stats.csv` — per-(task,method) aggregates (duration/steps/tokens/cost).
- `share_out/agent_runs_export.csv` — per-run final_result / action_names / errors (appendix excerpts).
- `comparison_report.json` — 48 agent-vs-human comparison records (LCS, duration deltas).
- `task_cards.json`, `human_runs.json` — task definitions and human baseline.
- `batch_manifests/*.json` — 12 run configs (6 A / code‑C, 6 B / code‑D).

## Figure checklist (generate these into `figures/`)

All figures are referenced in `main.tex` with an inline `% FIGURE SPEC` comment.
Summary:

- **fig1.pdf — System/architecture diagram.** Two side-by-side pipelines:
  *A* = `Task → Executor LLM (Doubao) → CDP browser action loop → done`, and
  *B* = same loop with a `DeepSeek navigator → opening plan + <current_step_focus>`
  box injected into the executor prompt. Show the event-driven BrowserSession /
  watchdogs and the action space. No data file; this is a schematic.
  *(Already a figure float in the Method section of `main.tex`, label `fig:arch`.)*
- **fig2.pdf — Strict success by task (A vs B).** Grouped bar chart. X = 4 tasks
  (+ overall); Y = strict success rate [0,1]; two bars/group; annotate k/6.
  Data: `batch_20260624_runs.csv`, `strict_success` grouped by
  `(task_id, experiment_id)` where experiment_id ∈ {C,D} (mapped to paper labels A,B).
- **fig3.pdf — Mean duration by task (A vs B), error bars.** Grouped bars or box
  plot; Y = duration_seconds; error bars = std. Data:
  `experiment_resource_report_stats.csv` columns `duration_seconds_mean`,
  `duration_seconds_std`, rows where `stats_experiment_id ∈ {C,D}` (exclude pooled).
- **fig4.pdf — Token cost / efficiency by task×method.** Grouped bars of
  `total_tokens_mean`, or scatter of `token_efficiency_score` vs `total_tokens`.
  Data: `experiment_resource_report_stats.csv` (`total_tokens_mean/std`,
  `token_efficiency_score_mean`, `execution_velocity_mean`), rows C and D
  (mapped to paper labels A,B).
- **fig5.pdf — Agent-vs-human LCS by task (A vs B).** Box/strip plot of
  `canonical_lcs` per task split by condition. Data: `comparison_report.json`,
  field `canonical_lcs`; drop null (non-comparable) entries.

## Status / TODO before submission

- [ ] Add `llncs.cls` and `splncs04.bst`.
- [ ] Generate `figures/fig1.pdf`…`fig5.pdf`; insert fig1 float in the Method section if desired.
- [ ] De-anonymize authors (or keep anonymized for double-blind).
- [ ] Verify all `% TODO verify` bib fields.
- [ ] Optional: add bootstrap CIs and conditions A/B (ChatBrowserUse executor
  presets) once those runs exist. (Note: the current paper uses the labels
  *Experiment A* and *Experiment B* for the Doubao‑based conditions C and D;
  the ChatBrowserUse presets A/B are not yet run.)
