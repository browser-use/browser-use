from __future__ import annotations
import warnings
warnings.filterwarnings('ignore')

import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from pathlib import Path

BASE_DIR = Path(r'D:\AI_Agent_Ali\browser-use')
DATA_DIR = BASE_DIR / 'tmp' / 'daily_task_eval'
OUT_DIR = BASE_DIR / 'paper' / 'pricai2026' / 'figures'
OUT_DIR.mkdir(parents=True, exist_ok=True)

COLORS = {'E': '#4E79A7', 'I': '#F28E2B', 'R-1': '#59A14F', 'R-3': '#E15759', 'R-5': '#B07AA1'}
CONDITIONS = ['E', 'I', 'R-1', 'R-3', 'R-5']
TASKS = ['shopping_cart_price_threshold', 'hospital_appointment_reschedule', 'github_clean_issue_audit', 'huggingface_model_constrained_selection']
TASK_LABELS = ['Shopping', 'Hospital', 'GitHub', 'HuggingFace']

SUCCESS_COUNTS = {
	'E': [(6,6), (3,6), (5,6), (6,6)],
	'I': [(6,6), (6,6), (6,6), (6,6)],
	'R-1': [(2,2), (2,2), (2,2), (0,2)],
	'R-3': [(2,2), (2,2), (2,2), (1,2)],
	'R-5': [(2,2), (2,2), (2,2), (2,2)]
}
R_OVERHEAD_MEDIANS = {'E': 0.0, 'I': 0.0078, 'R-1': 0.0925, 'R-3': 0.0392, 'R-5': 0.0290}

plt.rcParams['font.family'] = 'DejaVu Serif'
plt.rcParams['axes.labelsize'] = 9
plt.rcParams['xtick.labelsize'] = 8
plt.rcParams['ytick.labelsize'] = 8
plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False

all_runs = pd.read_csv(DATA_DIR / 'all_runs.csv')
milestone_summary = pd.read_csv(DATA_DIR / 'milestone_summary.csv')
with open(DATA_DIR / 'per_run_milestones.json') as f:
	per_run_milestones = json.load(f)

def save_fig(fig, name):
	fig.savefig(OUT_DIR / f'{name}.pdf', bbox_inches='tight')
	fig.savefig(OUT_DIR / f'{name}.png', dpi=300, bbox_inches='tight')
	plt.close(fig)

# Fig 2: Grouped bar chart - strict success rate by task×condition
fig, ax = plt.subplots(figsize=(7, 2.8))
x = np.arange(len(TASK_LABELS))
width = 0.15
for i, cond in enumerate(CONDITIONS):
	rates = [SUCCESS_COUNTS[cond][j][0]/SUCCESS_COUNTS[cond][j][1] for j in range(4)]
	offset = (i - 2) * width
	bars = ax.bar(x + offset, rates, width, label=cond, color=COLORS[cond],
		hatch='//' if cond.startswith('R-') else None,
		edgecolor='#555' if cond.startswith('R-') else None)
	for j, bar in enumerate(bars):
		k, n = SUCCESS_COUNTS[cond][j]
		ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, f'{k}/{n}',
			ha='center', va='bottom', fontsize=6.5)
ax.set_ylabel('Strict Success Rate')
ax.set_xticks(x)
ax.set_xticklabels(TASK_LABELS)
ax.set_ylim(0, 1.15)
ax.legend(ncol=5, loc='upper center', bbox_to_anchor=(0.5, 1.12), frameon=False)
ax.grid(axis='y', alpha=0.2)
fig.tight_layout()
save_fig(fig, 'fig2')

# Fig 3: Pareto scatter - cost vs success rate
fig, ax = plt.subplots(figsize=(3.5, 3))
for cond in CONDITIONS:
	df_c = all_runs[all_runs['paper_condition'] == cond]
	success_rate = df_c['strict_success'].mean()
	median_cost = df_c['total_cost'].median()
	marker = 's' if cond.startswith('R-') else 'o'
	is_prelim = cond.startswith('R-')
	ax.scatter(median_cost, success_rate, s=80, marker=marker,
		facecolors='none' if is_prelim else COLORS[cond],
		edgecolors=COLORS[cond], linewidths=1.5)
	offset = (0.02, 0.02) if cond != 'R-1' else (-0.04, 0)
	ax.text(median_cost + offset[0], success_rate + offset[1], cond, fontsize=8, color=COLORS[cond])
ax.set_xlabel('Median Total Cost ($)')
ax.set_ylabel('Strict Success Rate')
ax.grid(alpha=0.2)
ax.legend(['N=6', 'N=2 preliminary'], loc='lower right', frameon=False, fontsize=7, markerscale=0.7)
fig.tight_layout()
save_fig(fig, 'fig3')

# Fig 4: 3-panel distributions
fig, axes = plt.subplots(1, 3, figsize=(7, 2.6))
rng = np.random.default_rng(42)
metrics = [('number_of_steps', 'Number of Steps'), ('total_tokens', 'Total Tokens'), ('duration_seconds', 'Duration (s)')]
all_runs['total_tokens'] = all_runs['tokens_executor'] + all_runs['tokens_navigator']
for ax, (col, label) in zip(axes, metrics):
	data = [all_runs[all_runs['paper_condition']==c][col].dropna() for c in CONDITIONS]
	bp = ax.boxplot(data, labels=CONDITIONS, patch_artist=True, widths=0.5)
	for patch, cond in zip(bp['boxes'], CONDITIONS):
		patch.set_facecolor(COLORS[cond])
		patch.set_alpha(0.7)
	for i, (d, cond) in enumerate(zip(data, CONDITIONS)):
		jitter = rng.uniform(-0.15, 0.15, len(d))
		ax.scatter([i+1]*len(d) + jitter, d, s=20, color=COLORS[cond], alpha=0.6)
	ax.set_ylabel(label)
	ax.grid(axis='y', alpha=0.2)
fig.tight_layout()
save_fig(fig, 'fig4')

# Fig 5: 2-panel process metrics
fig, axes = plt.subplots(1, 2, figsize=(7, 2.8))
x = np.arange(len(TASK_LABELS))
width = 0.15
for metric_idx, (col, title) in enumerate([('milestone_coverage', 'Milestone Coverage'), ('stall_burden', 'Stall Burden')]):
	ax = axes[metric_idx]
	for i, cond in enumerate(CONDITIONS):
		means = []
		for task in TASKS:
			df_sub = milestone_summary[(milestone_summary['paper_condition']==cond) & (milestone_summary['task_id']==task)]
			means.append(df_sub[col].mean())
		offset = (i - 2) * width
		ax.bar(x + offset, means, width, label=cond if metric_idx==0 else '', color=COLORS[cond],
			hatch='//' if cond.startswith('R-') else None,
			edgecolor='#555' if cond.startswith('R-') else None)
	ax.set_ylabel(title)
	ax.set_xticks(x)
	ax.set_xticklabels(TASK_LABELS)
	ax.grid(axis='y', alpha=0.2)
	ax.text(0.02, 0.98, f'({chr(97+metric_idx)})', transform=ax.transAxes, fontsize=9, va='top', ha='left')
fig.legend(CONDITIONS, ncol=5, loc='upper center', bbox_to_anchor=(0.5, 1.05), frameon=False)
fig.tight_layout()
save_fig(fig, 'fig5')

# Fig 6: 2-panel navigator analysis
fig, axes = plt.subplots(1, 2, figsize=(7, 2.6))
ax = axes[0]
x = np.arange(len(CONDITIONS))
heights = [R_OVERHEAD_MEDIANS[c] for c in CONDITIONS]
for xi, (cond, h) in enumerate(zip(CONDITIONS, heights)):
	kw = dict(color=COLORS[cond])
	if cond.startswith('R-'):
		kw.update(hatch='//', edgecolor='#555')
	ax.bar(xi, h, **kw)
ax.set_xticks(x)
ax.set_xticklabels(CONDITIONS)
ax.set_ylabel('Median r_overhead')
ax.grid(axis='y', alpha=0.2)
ax.text(0.02, 0.98, '(a)', transform=ax.transAxes, fontsize=9, va='top', ha='left')

ax = axes[1]
ax.text(0.5, 0.5, 'Post-intervention recovery yield\nnot yet computed\n(R-* run experiment_id mapping pending)',
	transform=ax.transAxes, fontsize=8, ha='center', va='center', style='italic', color='gray')
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis('off')
ax.text(0.02, 0.98, '(b)', transform=ax.transAxes, fontsize=9, va='top', ha='left')
fig.tight_layout()
save_fig(fig, 'fig6')

# Fig 7: Case study dual-timeline
def classify_url(url):
	if not url or 'blank' in url.lower():
		return 'blank'
	if 'huggingface.co/models' in url:
		return 'filtered_list' if '?' in url else 'models_home'
	if 'huggingface.co/' in url and '/models' not in url:
		return 'model_detail'
	return 'blank'

STATE_COLORS = {'blank': '#e0e0e0', 'models_home': '#AEC7E8', 'filtered_list': '#4E79A7', 'model_detail': '#59A14F'}

runs = [
	('R-1', DATA_DIR / 'agent_runs/huggingface_model_constrained_selection/normal/exp-C1/20260625T050947Z/history.json', '050947', 34),
	('R-5', DATA_DIR / 'agent_runs/huggingface_model_constrained_selection/normal/exp-C5/20260625T053325Z/history.json', '053325', 13)
]

fig, axes = plt.subplots(2, 1, figsize=(7, 3.6), sharex=True)
for idx, (label, path, run_substr, n_steps) in enumerate(runs):
	ax = axes[idx]
	with open(path, encoding='utf-8') as f:
		data = json.load(f)
	history = data.get('history', [])

	states = [classify_url(step.get('state', {}).get('url', '')) for step in history]
	for i, state in enumerate(states):
		ax.barh(0, 1, left=i, color=STATE_COLORS[state], edgecolor='none', height=0.5)

	milestones = next((m for m in per_run_milestones if run_substr in m.get('run_id', '')), {})
	milestone_steps = milestones.get('milestone_steps', {})
	for step_num in milestone_steps.values():
		ax.axvline(step_num, color='black', linestyle=':', linewidth=1, alpha=0.6)

	if label == 'R-1':
		ax.axvspan(14, 34, alpha=0.08, color='red')
		ax.annotate('Step 14: navigator injects\nback-navigate → re-filter loop',
			xy=(13.5, 0), xytext=(20, 0.35), fontsize=7, color='red',
			arrowprops=dict(arrowstyle='->', color='red', lw=1))
	else:
		ax.text(0.5, 0.7, 'Linear path → done (13 steps)', transform=ax.transAxes,
			fontsize=8, ha='center', va='center')

	ax.set_yticks([0])
	ax.set_yticklabels([label], fontsize=9, weight='bold', color=COLORS[label])
	ax.set_ylim(-0.3, 0.3)
	ax.set_xlim(0, 35)
	ax.grid(axis='x', alpha=0.2)

axes[1].set_xlabel('Step')
axes[1].set_xticks(range(0, 36, 5))

handles = [plt.Rectangle((0,0),1,1, color=STATE_COLORS[s]) for s in ['blank', 'models_home', 'filtered_list', 'model_detail']]
handles.append(plt.Line2D([0], [0], color='black', linestyle=':', linewidth=1))
labels_legend = ['blank', 'models_home', 'filtered_list', 'model_detail', 'milestone']
fig.legend(handles, labels_legend, ncol=5, loc='lower center', bbox_to_anchor=(0.5, -0.02), frameon=False, fontsize=7)
fig.tight_layout()
save_fig(fig, 'fig7')

print('All figures generated successfully in paper/pricai2026/figures/')
